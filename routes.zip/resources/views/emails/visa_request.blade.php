<h2>New Visa Application</h2>
<p><strong>Name:</strong> {{ $visa->first_name }} {{ $visa->surname }}</p>
<p><strong>Nationality:</strong> {{ $visa->nationality }}</p>
<p><strong>Passport No:</strong> {{ $visa->passport_no }}</p>
<!-- Add more fields as needed -->
