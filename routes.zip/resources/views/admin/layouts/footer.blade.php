<footer class="footer mt-auto py-3 bg-light">
    <div class="container-fluid">
        <div class="row align-items-center">
            <div class="col-md-6 text-center text-md-start">
                <span class="text-muted">&copy; {{ date('Y') }} SkyBooking. All rights reserved.</span>
            </div>
            <div class="col-md-6 text-center text-md-end">
                <span class="text-muted">v{{ config('app.version', '1.0.0') }}</span>
            </div>
        </div>
    </div>
</footer>